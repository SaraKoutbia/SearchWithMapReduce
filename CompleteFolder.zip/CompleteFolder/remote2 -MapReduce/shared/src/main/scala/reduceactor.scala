/*
*  The client master actor creates:
*     * A master actor on the server which in turn will create the reducers on the server
*     * Reducer actors on the client, the number of reducers is specified in the config file
*     * Client and Server mapper actors.
* The (book title, book url) main.scala.input pairs are specified in the config file
*
* To start the client, run client.scala
* Run the server from server.scala
*
* */

package common

import akka.actor.{Actor, ActorRef}
import com.typesafe.config.ConfigFactory
import common.Jobs.{Jobs, _}
import scala.collection.mutable._


class AggregatorActor(selectedJob: Jobs, reducerActors: ActorRef) extends Actor {

  var remainingMappers = ConfigFactory.load.getInt("number-of-mappers")
  var reduceMap = HashMap[String, Int]()
  var aggHashMapOutput = HashMap[String, MutableList[Object]]()
  var totalNumberOfDocs = 0
  var docHashMap = HashMap[String, Int]()

  def matchTest(x: Jobs): (WordTitleBase, HashMap[String, MutableList[Object]]) => HashMap[String, MutableList[Object]] = x match {
    case Job1 => Aggregate.agg
    case Job2 => Aggregate.agg
    case Job3 => Aggregate.agg
    case Job4 => Aggregate.agg
    case TestingC=> Aggregate.agg
    case TestingD=> Aggregate.agg
    case TestingJ=> Aggregate.agg
  }

  def aggregateJob: (WordTitleBase, HashMap[String, MutableList[Object]]) => HashMap[String, MutableList[Object]] = {
    matchTest(selectedJob)
  }

  def log2(x: Double) = scala.math.log(x) / scala.math.log(2)

  def ApplyTfIdf(invertedIndex: HashMap[String, MutableList[Object]]): HashMap[String, scala.collection.immutable.Map[String, Double]] = {
    var output = HashMap[String, scala.collection.immutable.Map[String, Double]]()
    for (i <- invertedIndex) {
      val key = i._1
      val value = i._2
      output += (key -> value.groupBy(l => l).map(t => (t._1.toString(), (t._2.length * log2(totalNumberOfDocs.toDouble / value.distinct.length)))))
    }
    output
  }


  def receive = {
    case a: WordTitleBase =>
      try {
        aggHashMapOutput = aggregateJob(a, aggHashMapOutput)
      }
      catch {
        case e: Exception => println("Agg Actor - After receiving WordTitleBase msg: " + e)
      }

    case msg: String =>
      println(msg) //get the content go through the list of words

    case Flush => //decrement the count of mappers by one
      remainingMappers -= 1
      try {
        val reduceMapWordTit = Fold.fold(aggHashMapOutput) //some objects are too big, so I am compressing them before sending
        if (remainingMappers == 0) {
          val tfIdfHashMapOutput = ApplyTfIdf(aggHashMapOutput)
          //println("toatalNumberOfDocs is: " + totalNumberOfDocs)
          for (i <- tfIdfHashMapOutput.sliding(20, 20)) {
            reducerActors ! i
          }
          sender ! Done //needs to send Done to the master on the client
          reducerActors ! DoneAndDocCount(totalNumberOfDocs)
        }
      } catch {
        case e: Exception => println("Agg Actor - After receiving Flush msg: " + e)
      }


    case DocsCount =>
      totalNumberOfDocs = totalNumberOfDocs + 1

    case alldocs: SetTotalDocCount =>
      totalNumberOfDocs = alldocs.count


    case _ => println("Received unknown msg ")
  }
}
