/*
*  The client master actor creates:
*     * A master actor on the server which in turn will create the reducers on the server
*     * Reducer actors on the client, the number of reducers is specified in the config file
*     * Client and Server mapper actors.
* The (book title, book url) input pairs are specified in the config file
*
* To start the client, run client.scala
* Run the server from server.scala
*
* */

package common

import java.io.InputStream
import com.typesafe.config.ConfigFactory
import common.Jobs.Jobs
import scala.collection.mutable.{HashMap, MutableList}
import scala.io.Source

case class WordTitle(word: String, title: Object)

case class WordTitleBase(word: String, title: Object)

case class input(title: String, url: String)

case class SrvReducersToCreate(numbersOfReducers: Int)

case object DocsCount

case class SetTotalDocCount(count: Int)

case object StartTesting

case object Flush

case object Done

case class DoneAndDocCount(totalNumberOfDocs: Int)

case object Shutdown

case class Query(content: String)

case class JobAndQuery(job: Jobs, query: String)

case object QueryTesting {

  //parse files into hashmap
  def parseFileIntoHashMap(filename: String): HashMap[String, String] = {

    var fileHashMap = new HashMap[String, String]()
    val stream: InputStream = getClass.getResourceAsStream(filename)
    val lines = scala.io.Source.fromInputStream(stream).getLines
    var docTitle = ""
    val Pattern = "(\\.I.*)".r

    for (line <- lines) {
      line match {
        //create new entry in the hashmap
        case Pattern(i) =>
          //save title
          docTitle = line.substring(1).trim().replaceAll(" +", "")
          fileHashMap += (docTitle -> "")

        case _ =>
          //append to previous entry in the hashmap
          fileHashMap(docTitle) = fileHashMap(docTitle) + " " + line.replaceAll("(\\.[A-Z])", "").trim()
      }
    }
    println("parsed " + filename + " file: ")
    println(fileHashMap)

    fileHashMap
  }
}

case object Inputs {

  def getListOfTitleUrlPairs(): List[input] = {
    var title = ""
    var TitleUrlInputs = List[input]()
    val books = ConfigFactory.load.getStringList("books").toArray()
    for (book <- books) {
      val Pattern = "(http://.*)".r
      book match {
        case Pattern(http) => TitleUrlInputs = input(title, book.toString) :: TitleUrlInputs
        case _ => title = book.toString
      }
    }
    TitleUrlInputs
  }

  def getInput(selectedJob: Jobs): List[input] = selectedJob match {
    case Jobs.Job1 =>
      getListOfTitleUrlPairs()

    case Jobs.Job2 =>
      getListOfTitleUrlPairs()

    case Jobs.Job3 =>
      getListOfTitleUrlPairs()


    case Jobs.Job4 =>
      getListOfTitleUrlPairs()

    //case Jobs.Testing =>
      //does not call getInput
  }
}

case object Jobs extends Enumeration {
  type Jobs = Value
  val Job1, Job2, Job3, Job4, TestingC,TestingD, TestingJ, Null = Value
}

case object Compress {

  def compress3(reduceMapWordTit: HashMap[String, MutableList[Object]]): HashMap[String, MutableList[Object]] = {
    reduceMapWordTit
  }

  def compress2(reduceMapWordTit: HashMap[String, MutableList[Object]]): HashMap[String, MutableList[Object]] = {
    for (item <- reduceMapWordTit) {
      val word = item._1
      val value = item._2
      if (reduceMapWordTit(word).length > 20) {
        //compress items with more the 20 items
        reduceMapWordTit += (word -> MutableList("[" + reduceMapWordTit(word).length + "]" + value.head))
      }
    }
    reduceMapWordTit
  }
}

//--------------------------------------

case object Aggregate {

  def agg(wordtitle: WordTitleBase, wordsCountAggMap: HashMap[String, MutableList[Object]]): HashMap[String, MutableList[Object]] = {
    val word = wordtitle.word
    val title = wordtitle.title

    if (wordsCountAggMap.contains(word)) {
      wordsCountAggMap += (word -> (wordsCountAggMap(word).++(List(title.asInstanceOf[Object]))))
    }
    else
      wordsCountAggMap += (word -> MutableList(title))

    wordsCountAggMap
  }
}

//--------------------------------------

case object Fold {

  def fold(map: HashMap[String, MutableList[Object]]): HashMap[String, Object] = {
    var output = HashMap[String, Object]()
    for (i <- map) {
      val key = i._1
      val value = i._2
      output += (key -> value.groupBy(l => l).map(t => (t._1, t._2.length)))
    }
    output
  }
}

//--------------------------------------

case object Map {
  val STOP_WORDS_LIST = ConfigFactory.load.getStringList("STOP_WORDS_LIST").toArray()

  def testmap(title1: String, content: String): MutableList[WordTitleBase] = {
    val MapOutput = MutableList[WordTitleBase]()
    val pattern = """[a-zA-Z]+""".r //"""([A-Z]{1,}[a-z]{2,})+""".r
    val matches = pattern.findAllMatchIn(content)
    for (i <- matches) {
      val preprocessedW = i.toString()
      var stemmer = new Stemmer()
      stemmer.add(preprocessedW)
      stemmer.step1()
      stemmer.step2()
      stemmer.step3()
      stemmer.step4()
      stemmer.step5a()
      stemmer.step5b()
      val word = stemmer.b.toLowerCase()
      var id = title1.trim()
      if (!STOP_WORDS_LIST.contains(word.toLowerCase())) {
        MapOutput += WordTitleBase(word, id.asInstanceOf[Object])
      }
    }
    MapOutput
  }

  def map(title: String, url: String): MutableList[WordTitleBase] = {
    val MapOutput = MutableList[WordTitleBase]()
    var title1 = "Unknown"
    val html = Source.fromURL(url)
    val bookContent = html.mkString
    val seqIndex = 10000
    var seqContent = ""
    var seqNum = 0
    println("------------ " + title + "------------ ")

    if (!title.startsWith("<")) {
      title1 = title
      //the first sequence
      println("First sequence")
      println("Sequence number: " + seqNum)
      println("Sequence length:  " + seqContent.length() + ". Remaining book content length:  " + bookContent.substring((seqNum + 1) * seqIndex).length())
      seqContent = bookContent.substring(0, seqIndex - 1)
    }
    else {
      //not the first sequence
      seqNum = title.substring(title.indexOf('<') + 1, title.indexOf('>')).toInt
      title1 = title.substring(title.indexOf('>') + 1)
      if (bookContent.substring(seqNum * seqIndex - 1).length < seqIndex) {
        //if this is the last sequence
        seqContent = bookContent.substring(seqNum * seqIndex - 1)
        println("Last sequence. Sequence number: " + seqNum)
        println("SeqIndex: " + seqNum * seqIndex)
        println("Sequence length:  " + seqContent.length() + ".  End! ")
      }
      else {
        //not the first sequence and not last
        val lastbit = bookContent.substring(((seqNum + 1) * seqIndex) - 10, ((seqNum + 1) * seqIndex) - 1)
        var nextBlankPt = """[^a-zA-Z]+""".r
        var lastWordInSeq = nextBlankPt.findFirstIn(bookContent.substring(((seqNum + 1) * seqIndex) - 1, ((seqNum + 1) * seqIndex) + 100)).get

        var lastWordMissingLen = bookContent.substring(((seqNum + 1) * seqIndex) - 1, ((seqNum + 1) * seqIndex) + 100).indexOf(lastWordInSeq)
        if (lastWordMissingLen == -1)
          lastWordMissingLen = 0

        seqContent = bookContent.substring(seqNum * seqIndex - 1, ((seqNum + 1) * seqIndex) - 1 + lastWordMissingLen)
        var firstCompleteWordinSeq = nextBlankPt.findFirstIn(seqContent).get
        seqContent = seqContent.substring(seqContent.indexOf(firstCompleteWordinSeq))
        //println("----------seqContent.indexOf(firstCompleteWordinSeq): " + seqContent.indexOf(firstCompleteWordinSeq))

        println("First sequence")
        println("Sequence number: " + seqNum)
        println("Sequence length:  " + seqContent.length() + ". Remaining book content length:  " + bookContent.substring((seqNum + 1) * seqIndex).length())
      }
    }
    val pattern = """[a-zA-Z]+""".r //"""([A-Z]{1,}[a-z]{2,})+""".r
    val matches = pattern.findAllMatchIn(seqContent)
    for (i <- matches) {
      val preprocessedW = i.toString()
      var stemmer = new Stemmer()
      stemmer.add(preprocessedW)
      stemmer.step1()
      stemmer.step2()
      stemmer.step3()
      stemmer.step4()
      stemmer.step5a()
      stemmer.step5b()

      val word = stemmer.b.toLowerCase()
      var id = title1.trim()

      if (!STOP_WORDS_LIST.contains(word.toLowerCase())) {
        MapOutput += WordTitleBase(word, id.asInstanceOf[Object])
      }
    }
    if ((bookContent.substring(seqNum * seqIndex).length() > seqIndex - 2) && (2 < bookContent.substring((seqIndex * (seqNum + 1)) - 1).length))
      MapOutput += WordTitleBase("...", 0.asInstanceOf[Object])
    MapOutput
  }
}

