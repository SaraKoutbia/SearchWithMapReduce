
import com.typesafe.config.ConfigFactory

import scala.collection.mutable.{HashMap, MutableList}
import common.Jobs._
import common._
import akka.actor.Actor
import common.Jobs.Jobs


class ReducerActors(job: Jobs) extends Actor {
  var selectedJob = job
  var query = ""

  //non query dependent
  var aggHashMapOutput = HashMap[String, MutableList[Object]]()
  var aggHashMapOutputTfIdf = HashMap[String, Map[String, Double]]()
  var isdone = ConfigFactory.load.getInt("number-client-aggregators") + ConfigFactory.load.getInt("number-server-aggregators")
  var toatalNumberOfDocs = 0
  val STOP_WORDS_LIST = ConfigFactory.load.getStringList("STOP_WORDS_LIST").toArray()
  var docNorms = HashMap[String, Double]()
  var totaldocCount = 0

  //query dependent
  var TFreqInQuery = HashMap[String, Double]()
  var dfs = HashMap[String, Double]()
  var scores = HashMap[String, Double]()
  var tfIdfQuery = HashMap[String, Double]()
  var cosine = HashMap[String, Double]()
  var dice = HashMap[String, Double]()
  var jaccard = HashMap[String, Double]()
  var queryNorm = 0.0
  var results =  HashMap[String, Double]()





  def matchTest(x: Jobs) = x match {
    case Job1 =>
      computeCosine
    case Job2 =>
      computeDice
    case Job3 =>
      computeJaccard
    case Job4 => //dot product
      results = scores
      println("Dot Product:  " + scores)
    case TestingC =>
      computeCosine
    case TestingD =>
      computeDice
    case TestingJ =>
      computeJaccard
  }

  def log2(x: Double) = scala.math.log(x) / scala.math.log(2)

  def processQuery() = {
    val pattern = """[a-zA-Z]+""".r
    val matches = pattern.findAllMatchIn(query)
    for (i <- matches) {
      val preprocessedW = i.toString()
      var stemmer = new Stemmer()
      stemmer.add(preprocessedW)
      stemmer.step1()
      stemmer.step2()
      stemmer.step3()
      stemmer.step4()
      stemmer.step5a()
      stemmer.step5b()
      val word = stemmer.b.toLowerCase()

      if (!STOP_WORDS_LIST.contains(word.toLowerCase())) {
        if (TFreqInQuery.contains(word))
          TFreqInQuery(word) = TFreqInQuery(word) + 1
        else
          TFreqInQuery += (word -> 1)
      }
    }
    println("Original Query: " + query)
    println("Term Freqs in the Query:  " + TFreqInQuery)
  }

  //query dependent
  def computeTermTfIdf(totaldocCount: Int): HashMap[String, Double] = {
    for (queryTerm <- TFreqInQuery) {
      if (aggHashMapOutputTfIdf.contains(queryTerm._1)) {
        dfs += (queryTerm._1 -> aggHashMapOutputTfIdf(queryTerm._1).size)
      }
      else {
        dfs += (queryTerm._1 -> 0)
      }
    }
    println("dfs:  " + dfs)
    val idfs = dfs.map(a => (a._1, if (a._2 == 0) 0 else log2(totaldocCount / a._2)))
    println("idfs:  " + idfs)
    val tfIdfQuery = TFreqInQuery.map(a => (a._1, a._2 * idfs(a._1)))
    println("tfIdfQuery:  " + tfIdfQuery)
    tfIdfQuery
  }

  def computeDotProduct() = {
    for (i <- tfIdfQuery) {
      val termI = i._1
      if (aggHashMapOutputTfIdf.contains(termI)) {
        for (j <- aggHashMapOutputTfIdf(termI)) {
          //ex: j = Map(D2 -> 0.0, D1 -> 0.0, D3 -> 0.0
          if (scores.contains(j._1)) //ex: j._1= D2
            scores(j._1) = scores(j._1) + (j._2 * tfIdfQuery(termI))
          else {
            scores += (j._1 -> j._2 * tfIdfQuery(termI))
          }
        }
      }
    }
    println("Dot Product:  " + scores)
  }

  def computeDocsNorms() = {
    for (i <- aggHashMapOutputTfIdf) {
      val key = i._1
      val value = i._2
      for (j <- value) {
        val docId = j._1
        val docFreq = j._2
        if (docNorms.contains(docId)) {
          docNorms(docId) = docNorms(docId) + math.pow(docFreq, 2)
        }
        else {
          docNorms += (docId -> math.pow(docFreq, 2))
        }
      }
    }
    docNorms.foreach(i => docNorms(i._1) = math.sqrt(i._2))
    println("Norms of all docs:  " + docNorms)
  }

  def queryVecNorm() = {
    for (i <- tfIdfQuery) {
      queryNorm += math.pow(i._2, 2)
    }
    queryNorm = math.sqrt(queryNorm)
    println("Norm of the query:  " + queryNorm)
  }

  def computeCosine() = {
    for (i <- scores) {
      cosine += i._1 -> i._2 / (docNorms(i._1) * queryNorm)
    }
    println("Cosine:  " + cosine)
    results = cosine
  }

  def computeDice() = {
    for (i <- scores) {
      dice += i._1 -> 2 * i._2 / (math.pow(docNorms(i._1), 2) + math.pow(queryNorm, 2) - i._2)
    }
    println("Dice:  " + dice)
    results =dice
  }

  def computeJaccard() = {
    for (i <- scores) {
      jaccard += i._1 -> i._2 / (math.pow(docNorms(i._1), 2) + math.pow(queryNorm, 2))
    }
    println("Jaccard:  " + jaccard)
    results =jaccard
  }


  def receive = {

    case jobAndQ: JobAndQuery =>
      //query dependent
      TFreqInQuery.clear()
      dfs.clear() // = HashMap[String, Double]()
      scores.clear() //= HashMap[String, Double]()
      tfIdfQuery.clear() //= HashMap[String, Double]()
      cosine.clear() // = HashMap[String, Double]()
      dice.clear()
      jaccard.clear()
      queryNorm = 0.0

      query = jobAndQ.query
      selectedJob = jobAndQ.job
      processQuery()
      //Computing the tems idfs
      tfIdfQuery = computeTermTfIdf(totaldocCount)
      //documents dot product with query
      computeDotProduct()
      //norm of the query vector
      queryVecNorm()
      //compute cosine
      matchTest(selectedJob)
      var sortedResults = results.toSeq.sortWith(_._2>_._2).take(10)
      println("------------RESULTS IN Decreasing Order Of Similatrity------------")
      for(i <-sortedResults)
        println("\t\t\t" + i )




    case qry: Query =>
      query = qry.content
      processQuery()

    case a: HashMap[String, scala.collection.immutable.Map[String, Double]] =>
      try {
        aggHashMapOutputTfIdf = aggHashMapOutputTfIdf.++(a)
      }
      catch {
        case e: Exception => println("Reducer Actor - After receiving HashMap[String, scala.collection.immutable.Map[String, Double]]: \n"
          + e)
      }

    case a: HashMap[String, MutableList[Object]] =>
      try {
        aggHashMapOutput = aggHashMapOutput.++(a)
      }
      catch {
        case e: Exception => println("Reducer Actor - After receiving HashMap[String, MutableList[Object]]: " + e)
      }

    case docCount: DoneAndDocCount =>
      isdone = isdone - 1
      try {
        if (isdone == 0) {
          totaldocCount = docCount.totalNumberOfDocs
          println("Reducer " + self.path.name + " output: " + aggHashMapOutputTfIdf)

          //Computing the tems idfs
          tfIdfQuery = computeTermTfIdf(totaldocCount)

          //documents dot product with query
          computeDotProduct()

          //Computing the norm of the documents
          computeDocsNorms()

          //norm of the query vector
          queryVecNorm()

          //compute cosine
          matchTest(selectedJob)
          var sortedResults = results.toSeq.sortWith(_._2>_._2).take(10)
          println("------------RESULTS IN Decreasing Order Of Similatrity------------")
          for(i <-sortedResults )
            println("\t\t\t" + i )
        }
      } catch {
        case e: Exception => println("Reducer Actor - After receiving docCount msg: " + e)
      }


    case _ => println(self.path.name + "Received unknown msg")
  }
}