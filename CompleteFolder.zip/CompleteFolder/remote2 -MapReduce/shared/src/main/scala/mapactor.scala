/*
Mappactor, and also the aggregatoractor and reduceractor, take an argument in their constructor that specifies the particular job the user selected.
The mapper function corresponding to the job being run is retrieved from messages.scala and a local function mapJob with the same signature is set to the mapper function.
 When the mapper receives an input value, it calls the mapJob function on it.

* To start the client, run client.scala
* Run the server from server.scala
*
* */
package common

import akka.actor.{Actor, ActorRef}
import com.typesafe.config.ConfigFactory
import common.Jobs.{Jobs, _}

import scala.collection.mutable.MutableList

class MapActor(aggregatorActors: List[ActorRef], selectedJob: Jobs) extends Actor {


  val numReducers = aggregatorActors.size

  def matchTest(x: Jobs): (String, String) => MutableList[WordTitleBase] = x match {
    case Job1 => Map.map
    case Job2 => Map.map
    case Job3 => Map.map
    case TestingC => Map.testmap
    case TestingD => Map.testmap
    case TestingJ => Map.testmap
  }

  def mapJob: (String, String) => MutableList[WordTitleBase] = {
    matchTest(selectedJob)
  }
  var toatalNumberOfDocs = ConfigFactory.load.getStringList("books").toArray().length/2 // STOP_WORDS_LIST//0

  def receive = {

    case input(title: String, url: String) =>
      try {
        var mapperOutput = mapJob(title, url)
        var i = 0
        //the book is not yet complete, the sequence is not the last one
        while (mapperOutput.last.word == "...") {
          //remove the last item
          mapperOutput = mapperOutput.take(mapperOutput.size - 1)
          //send sequence i to the aggregator
          for (i <- mapperOutput) {
            val myword = i.word
            var index = Math.abs((myword.hashCode()) % numReducers)
            aggregatorActors(index) forward i //send it to the appropriate reduce Actor
          }
          i = i + 1
          //request the next sequence to be processed
          mapperOutput = mapJob("<" + i + ">" + title, url)
        }
        //send the last sequence to the aggregator
        for (i <- mapperOutput) {
          val myword = i.word
          var index = Math.abs((myword.hashCode()) % numReducers)
          aggregatorActors(index) forward i //send it to the appropriate reduce Actor
        }

        for (i <- 0 until (numReducers)) {
          aggregatorActors(i) forward SetTotalDocCount(toatalNumberOfDocs)
        }


        //toatalNumberOfDocs = toatalNumberOfDocs + 1
      }
      catch {
        case e: Exception => println("Map Actor - After receiving input(title, url) msg: " + e)
      }


    case msg: String =>
      println(self.path + " Got msg:  " + msg)


    case Flush =>
      for (i <- 0 until (numReducers)) {
        aggregatorActors(i) forward Flush //forward the flush to all the reducers
      }


    case StartTesting =>

      try {
        var DocFile = "/ADI.ALL"
        val docHashMap = QueryTesting.parseFileIntoHashMap(DocFile)
        toatalNumberOfDocs = docHashMap.size
        for (file <- docHashMap) {
          //each file is a doc or a query
          var mapperOutput = mapJob(file._1, file._2)

          for (i <- mapperOutput) {
            val myword = i.word
            var index = Math.abs((myword.hashCode()) % numReducers)
            aggregatorActors(index) forward i //send it to the appropriate reduce Actor
          }
        }
        for (i <- 0 until (numReducers)) {
          aggregatorActors(i) forward SetTotalDocCount(toatalNumberOfDocs)
        }
        //        var QueryFile = "/ADI.QRY"
        //        val queryHashMap = QueryTesting.parseFileIntoHashMap(QueryFile)

      } catch {
        case e: Exception => println("Map Actor - After receiving StartTesting msg: " + e)
      }


    case _ => println("Received unknown msg")
  }
}
