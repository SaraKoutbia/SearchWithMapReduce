/*

The client master actor creates:
  1.	A master actor on the server which in turn creates aggregators on the server.
  2.	Reducers and mappers actors on both the client and the server using a roundRobin router.

The number of mappers, reducers and aggregators to create is specified in the config file
The (book title, book url) and (page content, page url) input pairs are specified in the config file too.

The server master actor is in charge of creating the aggregator actors on the sever.
When the aggregators are all created, it notifies the client master by sending the actor references.

* To start the client, run client.scala
* Run the server from server.scala
*
* */

import akka.actor.{Actor, ActorRef, Props}
import common.Jobs.Jobs
import common._


class MasterActor(selectedJobAndQ: JobAndQuery, reducerActors: ActorRef) extends Actor {
  val selectedJob = selectedJobAndQ.job
  val query= selectedJobAndQ.query
  var aggregatorActors = List[ActorRef]()
  var mapActors = List[ActorRef]()

  def receive = {
    case SrvReducersToCreate(numberServerReducers) =>
      println("Server received a request to create " + numberServerReducers + " reducer actors. Sender: " + sender.path)
      for (i <- 0 until numberServerReducers)
        aggregatorActors = context.actorOf(Props(classOf[AggregatorActor], selectedJob: Jobs, reducerActors), name = "server-aggregator" + i) :: aggregatorActors
      sender ! aggregatorActors

    case msg: String => println(self.path.toStringWithoutAddress + " received " + msg + " from " + sender)

    case _ => println("Received unknown msg ")
  }
}
