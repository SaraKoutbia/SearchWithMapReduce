/*
*  The client master actor creates:
*     * A master actor on the server which in turn will create the reducers on the server
*     * Reducer actors on the client, the number of reducers is specified in the config file
*     * Client and Server mapper actors.
* The (book title, book url) main.scala.input pairs are specified in the config file
*
* To start the client, run client.scala
* Run the server from server.scala
*
* */

 import akka.actor.ActorSystem
import com.typesafe.config.ConfigFactory


object Server extends App {
  val system = ActorSystem("MapReduceServer", ConfigFactory.load.getConfig("server"))
  println("Server ready")
  Thread.sleep(6000000)
  system.shutdown
}
