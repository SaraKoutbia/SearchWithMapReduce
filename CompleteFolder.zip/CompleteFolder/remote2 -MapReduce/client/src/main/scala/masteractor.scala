/*
*  The client master actor creates:
    1.	A master actor on the server which in turn creates aggregators on the server.
    2.	Reducers and mappers actors on both the client and the server using a roundRobin router.
 The number of mappers, reducers and aggregators to create is specified in the config file
* The (book title, book url) main.scala.input pairs are specified in the config file
*
* To start the client, run client.scala
* Run the server from server.scala
*
* */

import java.awt.{Font, Dimension}

import akka.actor._
import akka.remote.routing.RemoteRouterConfig
import akka.routing.{Broadcast, RoundRobinPool}
import com.typesafe.config.ConfigFactory
import common.Jobs.Jobs
import common._

import scala.swing._
import scala.swing.event.ButtonClicked


class MasterActor(selectedJobAndQ: JobAndQuery, redActors1: ActorRef) extends Actor {

  val selectedJob = selectedJobAndQ.job
  val query = selectedJobAndQ.query
  val numberOfMappers = ConfigFactory.load.getInt("number-of-mappers")
  val numberClientAggregators = ConfigFactory.load.getInt("number-client-aggregators")
  val numberServerAggregators = ConfigFactory.load.getInt("number-server-aggregators")
  val numberOfReducers = ConfigFactory.load.getInt("number-of-reducers")
  var pending = numberServerAggregators + numberClientAggregators
  val books = ConfigFactory.load.getStringList("books").toArray()
  val urls = ConfigFactory.load.getStringList("urls").toArray()
  var aggregatorActors = List[ActorRef]()
  val addresses = Seq(Address("akka", "MapReduceClient"), Address("akka.tcp", "MapReduceServer", "127.0.0.1", 3000))


  //creating reducers actors on both client and server
  var reducerActors =
    context.actorOf(RemoteRouterConfig(RoundRobinPool(numberOfReducers), addresses).props(Props(classOf[ReducerActors], selectedJob)))
  reducerActors ! Broadcast(Query(query))

  //creating aggregator actors on both client and server
  for (i <- 0 until numberClientAggregators)
    aggregatorActors = context.actorOf(Props(classOf[AggregatorActor], selectedJob: Jobs, reducerActors: ActorRef), name = "client-aggregator" + i) :: aggregatorActors


  //creating a master actor on the sever and ask it to create reducers
  val serverMasterActor = context.system.actorOf(Props(classOf[MasterActor], selectedJobAndQ: JobAndQuery, reducerActors), name = "sampleActor")
  serverMasterActor ! SrvReducersToCreate(numberServerAggregators)
  var mapActors = serverMasterActor //just initialization, will be overwritten


  def run(selectedJobAndQuery: JobAndQuery) = {
    println("\n----------------------------New Search----------------------------")
    reducerActors ! Broadcast(selectedJobAndQuery)
  }

  def receive = {
    // references of server reducers came back
    case serverReducersRefs: List[ActorRef] =>
      println("The master on the server just created " + serverReducersRefs.size + " aggregator actors.")
      aggregatorActors = serverReducersRefs ::: aggregatorActors

      val addresses = Seq(Address("akka", "MapReduceClient"),
        Address("akka.tcp", "MapReduceServer", "127.0.0.1", 3000))

      //creating map actors
      mapActors =
        context.actorOf(RemoteRouterConfig(RoundRobinPool(numberOfMappers), addresses).props(Props(classOf[MapActor],
          aggregatorActors, selectedJob)))

      //client master sending main.scala.input(title, url) pairs to the mapActors...
      selectedJob match {
        case Jobs.TestingC =>
          mapActors ! StartTesting
        case Jobs.TestingD =>
          mapActors ! StartTesting
        case Jobs.TestingJ =>
          mapActors ! StartTesting
        case _ =>
          for (titleUrlpair <- Inputs.getInput(selectedJob)) {
            mapActors ! titleUrlpair
          }
      }
      //flushing when all the pairs have been entered in the config file
      mapActors ! Broadcast(Flush)

    case msg: String =>
      println(msg)

    case Shutdown =>
      context.system.shutdown


    case Done =>
      pending -= 1
      if (pending == 0) {
        //Indexing Job Completed
        val ui = new MainFrame {
          preferredSize = new Dimension(700, 400)
          title = "Enter a Query and select a similarity method"

          def newField = new TextField {
            columns = 40
          }

          val query = newField

          contents = new BoxPanel(Orientation.Vertical) {
            val radioButton1 = new RadioButton("Cosine")
            val radioButton2 = new RadioButton("Dice")
            val radioButton3 = new RadioButton("Jaccard")
            val radioButton4 = new RadioButton("Dot Product")
            val radioButton5 = new RadioButton("Test Cosine")
            val radioButton6 = new RadioButton("Test Dice")
            val radioButton7 = new RadioButton("Test Jaccard")
            val submit = new Button("Run") {
              verticalTextPosition = Alignment.Bottom
            }
            val queryLabel = new Label {
              text = "Query:"
              font = new Font("ariel", java.awt.Font.PLAIN, 20)
              verticalTextPosition = (Alignment.Center)
            }
            val simMethodLabel = new Label {
              text = "Similarity:"
              font = new Font("ariel", java.awt.Font.PLAIN, 20)
            }
            val dirFileSelector = List(
              radioButton1, radioButton2, radioButton3, radioButton4,radioButton5,
              radioButton6, radioButton7, submit)
            contents += queryLabel
            contents += new FlowPanel(queryLabel, query) {
              maximumSize = new Dimension(600, 80)

            }
            contents += simMethodLabel
            contents += radioButton4
            contents += radioButton1
            contents += radioButton2
            contents += radioButton3
            contents += radioButton5
            contents += radioButton6
            contents += radioButton7
            contents += submit

            var selectedJob = Jobs.Null

            new ButtonGroup(radioButton1, radioButton2, radioButton3, radioButton4,
              radioButton5, radioButton6, radioButton7)
            try {
              dirFileSelector.foreach(listenTo(_))
              reactions += {
                case ButtonClicked(button) => {
                  button.text match {
                    case "Dot Product" => title = "Computing similarity using the dot product"
                      selectedJob = Jobs.Job4
                    case "Cosine" => title = "Computing the Cosine similarity"
                      selectedJob = Jobs.Job1 //WordTitleBase(word, id.asInstanceOf[Object])
                    case "Dice" => title = "Computing similarity using Dice coefficient"
                      selectedJob = Jobs.Job2
                    case "Jaccard" => title = "Computing similarity using Jaccard's coefficient"
                      selectedJob = Jobs.Job3
                    case "Test Cosine" =>
                      selectedJob = Jobs.TestingC
                    case "Test Dice" =>
                      selectedJob = Jobs.TestingD
                    case "Test Jaccard" =>
                      selectedJob = Jobs.TestingJ

                    case "Run" => // title = "RadioButton 2"
                      if (selectedJob != Jobs.Null) {
                        //dispose()
                        run(JobAndQuery(selectedJob, query.text))
                      }
                  }
                }
              }
            }
            catch {
              case e: Exception => println(" -- " + e)
            }
          }
        }
        ui.visible = true
      }


    case _ => println("Received unknown msg")
  }
}



