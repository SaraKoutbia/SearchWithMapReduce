/*
* Creating the client master actor.
*  This client master actor  will later create:
*     * A master actor on the server which in turn will create the reducers on the server
*     * Reducer actors on the client, the number of reducers is specified in the config file
*     * Client and Server mapper actors.
* The (book title, book url) and (page content, page url)  input pairs are specified in the config file
*
* To start the client, run client.scala
* Run the server from server.scala
*
* */


import java.awt.Dimension

import akka.actor.{ActorSystem, Props}
import com.typesafe.config.ConfigFactory
import common.{JobAndQuery, Jobs}
import scala.swing._
import scala.swing.event._


object Client extends SimpleSwingApplication {

  object AllDone extends Exception {}

  def run(selectedJob: JobAndQuery) = {
    val system = ActorSystem("MapReduceClient", ConfigFactory.load.getConfig("remotelookup"))
    val master = system.actorOf(Props(classOf[MasterActor], selectedJob: JobAndQuery, null), name = "master")
    //Thread.sleep(6000000)
    //system.shutdown
  }

  var selectedJob = Jobs.Null

  def top = new MainFrame {
    preferredSize = new Dimension(700, 400)
    title = "Enter a Query and select a similarity method"

    def newField = new TextField {
      columns = 40
    }

    val query = newField

    contents = new BoxPanel(Orientation.Vertical) {
      val radioButton1 = new RadioButton("Cosine")
      val radioButton2 = new RadioButton("Dice")
      val radioButton3 = new RadioButton("Jaccard")
      val radioButton4 = new RadioButton("Dot Product")
      val radioButton5 = new RadioButton("Test Cosine")
      val radioButton6 = new RadioButton("Test Dice")
      val radioButton7 = new RadioButton("Test Jaccard")
      val submit = new Button("Run") {
        verticalTextPosition = Alignment.Bottom
      }
      val queryLabel = new Label {
        text = "Query:"
        font = new Font("ariel", java.awt.Font.PLAIN, 20)
        verticalTextPosition = (Alignment.Center)
      }
      val simMethodLabel = new Label {
        text = "Similarity:"
        font = new Font("ariel", java.awt.Font.PLAIN, 20)
      }
      val dirFileSelector = List(
        radioButton1, radioButton2, radioButton3, radioButton4, radioButton5,
        radioButton6, radioButton7, submit)
      contents += queryLabel
      contents += new FlowPanel(queryLabel, query) {
        maximumSize = new Dimension(600, 80)

      }
      contents += simMethodLabel
      contents += radioButton4
      contents += radioButton1
      contents += radioButton2
      contents += radioButton3
      contents += radioButton5
      contents += radioButton6
      contents += radioButton7
      contents += submit

      new ButtonGroup(radioButton1, radioButton2, radioButton3, radioButton4,
        radioButton5, radioButton6, radioButton7)
      try {
        dirFileSelector.foreach(listenTo(_))
        reactions += {
          case ButtonClicked(button) => {
            button.text match {
              case "Dot Product" => title = "Computing similarity using the dot product"
                selectedJob = Jobs.Job4
              case "Cosine" => title = "Computing the Cosine similarity"
                selectedJob = Jobs.Job1 //WordTitleBase(word, id.asInstanceOf[Object])
              case "Dice" => title = "Computing similarity using Dice coefficient"
                selectedJob = Jobs.Job2
              case "Jaccard" => title = "Computing similarity using Jaccard's coefficient"
                selectedJob = Jobs.Job3
              case "Test Cosine" => title ="Test Cosine"
                selectedJob = Jobs.TestingC
              case "Test Dice" => title ="Test Dice"
                selectedJob = Jobs.TestingD
              case "Test Jaccard" => title ="Test Jaccard"
                selectedJob = Jobs.TestingJ

              case "Run" => // title = "RadioButton 2"
                if (selectedJob != Jobs.Null) {
                  dispose()
                  run(JobAndQuery(selectedJob, query.text))
                }
            }
            println("\n------------------------" + title + "------------------------")
          }
        }
      }
      catch {
        case e: Exception => println(" -- " + e)
      }
    }
  }
}



